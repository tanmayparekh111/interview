'''
*
**
***
****

****
***
**
*
'''

n = 5
reverse = True

if not reverse:
    for i in range(n):
        print("* "* (i+1))
else:
    for i in range(n):
        print("* "*(n-i))





