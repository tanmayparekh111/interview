'''

* * *
 * *
  *

'''

n = 3 
for i in range(n):
    print(' '*i+'* '*(n-i))
    
