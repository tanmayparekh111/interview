def chek_prime(n,f):
    for i in range(2,int(n**0.5)+1):
        if n%i == 0:
            f = False
            break
    return f
        
        


def give_range_for_prime(primerange):
    primerange+=1
    empl = []
    for n in range(2,primerange):
        f = True
        if chek_prime(n,f):
            empl.append(n)
        else:
            pass
    return empl
empl = give_range_for_prime(500)
print(empl)

