'''
if n is even for eg: 7

then 4 is in top and 3 is in bottom
    and while running bottom we will place bottom +=1 
    and skip iteration for the 0th index

   *
  * *
 * * *
* * * *
 * * *
  * *
   *

if n is odd lets say 6 then will define top bottom directly by n/2
  *
 * *
* * *
* * *
 * *
  *
'''



n = 8
if n%2==0:
    top = int(n/2)
    bottom=int(n/2)
    for i in range(top):
        print(" "*(top-i-1)+'* '*(i+1))

    for j in range(bottom):
        print(" "*j+'* '*(bottom-j))


else:
    top=int((n+1)/2)
    bottom = int((n-1)/2)
    for i in range(top):
        print(" "*(top-i-1)+'* '*(i+1))

    for j in range(bottom+1):
        if j == 0:
            continue
        print(" "*j+'* '*(bottom+1-j))


