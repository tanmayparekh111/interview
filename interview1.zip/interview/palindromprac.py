'''
palindrom number is reverse of that number is also the same
and palindrom string means reverse of that string is also the smae 

imp note: here
            n = 127  
            print(n//10) = 12 
            simple n/10 = 12.7

            n = 122
            print(n//10) = 12
            simple n/10 = 12.2

            10//10 = 1
            1//10 = 0

            if you are given a string then you need to simply just type [::-1],
            and then you will reversed string compared it with the previous one
'''
n = 121
o = n
r = 0

while n>0:
    digit = n%10
    r = r*10+digit
    n = n//10

if r == o:
    print("pass")
else:
    print("fail")


