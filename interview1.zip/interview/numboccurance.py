occuring_num = 3
occuring_num = str(occuring_num)
s = "123456adsu123123"
l = list(s)

x = [i for i in l if i==occuring_num]
occurance = len(x)

print(x)
print(occurance)